# resort-pool > 2024-08-25 1:38pm
https://universe.roboflow.com/adamsstudio/resort-pool

Provided by a Roboflow user
License: CC BY 4.0

